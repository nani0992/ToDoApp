# Java Swing To-Do App

## Features
- Add and delete tasks
- Scrollable task list
- Simple Java Swing GUI

## Tools Used
- Java
- Swing (JFrame, JButton, JTextField, JList, JScrollPane)

## How to Run
1. Open in IntelliJ or Eclipse
2. Compile and run `ToDoApp.java`

## Author
Your Name